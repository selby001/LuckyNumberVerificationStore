const express = require('express');
const fetch = require('node-fetch');
const app = express();
const port = 3000;

app.use(express.static('public'));

app.get('/getSMSDetails', async (req, res) => {
    const numberUuid = req.query.numberUuid;
    const apiUrl = `https://api.globalsms.io/api_gsim/v1/public/order_number/${numberUuid}/sms_list`;

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            return res.status(404).send('Could not find a cake matching this query');
        }
        const data = await response.json();
        res.send(data);
    } catch (error) {
        res.status(500).send(`Error: ${error.message}`);
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

